<hr />
<div id="Sub">
  <?php include_once("banner.php") ?>
</div>
