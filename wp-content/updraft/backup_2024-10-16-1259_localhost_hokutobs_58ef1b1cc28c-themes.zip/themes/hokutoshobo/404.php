<?php
header( "location: " . home_url() );
exit;
?>