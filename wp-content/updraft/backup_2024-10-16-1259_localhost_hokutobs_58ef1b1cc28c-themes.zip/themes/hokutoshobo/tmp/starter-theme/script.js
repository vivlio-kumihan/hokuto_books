"use strict";

var test = "text";
console.log(test);