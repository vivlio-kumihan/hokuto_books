  <footer>
    <small>&#169; <?php bloginfo( 'name' ) ?></small>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>