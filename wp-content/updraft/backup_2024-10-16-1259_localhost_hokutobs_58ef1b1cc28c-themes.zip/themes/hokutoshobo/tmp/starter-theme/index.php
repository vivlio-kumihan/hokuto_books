<?php get_header(); ?>

<div class="wrapper">
  <main>
    <p>this is index.php</p>
  </main>
  <?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>