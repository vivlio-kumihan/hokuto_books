<?php
  // 分割したファイルの読み込み
  get_template_part( 'functions/common' );
  get_template_part( 'functions/display' );
  get_template_part( 'functions/custom-menu' );
  get_template_part( 'functions/search' );
  get_template_part( 'functions/sidebar' );
  get_template_part( 'functions/delete-code' );
  get_template_part( 'functions/ogp' );