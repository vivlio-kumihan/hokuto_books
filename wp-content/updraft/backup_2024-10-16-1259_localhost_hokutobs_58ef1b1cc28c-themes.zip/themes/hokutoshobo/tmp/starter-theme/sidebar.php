<aside>
  <?php dynamic_sidebar( 'widget' ); ?>
</aside>