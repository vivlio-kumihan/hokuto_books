wp-config.php のデータベース設定の確認については、

define('DB_NAME', 'hokuto-bs-db');

/** MySQL データベースのユーザー名 */
define('DB_USER', 'root');

/** MySQL データベースのパスワード */
define('DB_PASSWORD', 'root');

/** MySQL のホスト名 */
define('DB_HOST', 'localhost:8889');

/** データベースのテーブルを作成する際のデータベースのキャラクターセット */
define('DB_CHARSET', 'utf8');

/** データベースの照合順序 (ほとんどの場合変更する必要はありません) */
define('DB_COLLATE', '');

/** WPを認識させる */
define('WP_HOME', 'http://localhost:8888/hokuto-bs');
define('WP_SITEURL', 'http://localhost:8888/hokuto-bs');

以上のように変更はしていません。

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';
これについては、your_passwordは、rootでいいですよね。


データベースサーバ
サーバ： Localhost via UNIX socket
サーバの種類： MySQL
サーバの接続： SSLは使用されていません ドキュメント
サーバのバージョン： 8.0.35 - Source distribution
プロトコル バージョン: 10
ユーザ： root@localhost
サーバの文字セット: UTF-8 Unicode (utf8mb4)
ウェブサーバ
Apache/2.4.58 (Unix) OpenSSL/1.1.1u mod_fastcgi/mod_fastcgi-SNAP-0910052141
データベースクライアントのバージョン： libmysql - mysqlnd 8.2.20
PHP 拡張: mysqli ドキュメント curl ドキュメント mbstring ドキュメント sodium ドキュメント
PHP のバージョン: 8.2.20

phpMyAdminに書いてある情報。
データベースサーバ
サーバ： Localhost via UNIX socket
サーバの種類： MySQL
サーバの接続： SSLは使用されていません ドキュメント
サーバのバージョン： 8.0.35 - Source distribution
プロトコル バージョン: 10
ユーザ： root@localhost
サーバの文字セット: UTF-8 Unicode (utf8mb4)
ウェブサーバ
Apache/2.4.58 (Unix) OpenSSL/1.1.1u mod_fastcgi/mod_fastcgi-SNAP-0910052141
データベースクライアントのバージョン： libmysql - mysqlnd 8.2.20
PHP 拡張: mysqli ドキュメント curl ドキュメント mbstring ドキュメント sodium ドキュメント
PHP のバージョン: 8.2.20

サーバーやMySQL, PHPのバージョンは最新版になったということでいいですよね。

で、
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'root';
実行しましたが、やはり接続エラーです。


wp_blogsで問題ありです。
しまった、MySQLのバージョンをあげる前にDBバックアップするのしなかった。
勘違いしていた。
最初にエクスポートしてきたsqlを使ってしまった。
だから編集できていないんだ。

blog_id site_id  domain  path  registered  last_updated  public  archived  mature  spam  deleted lang_id
1 1 www.hokutoshobo.jp /  2012-05-28 15:39:41 2021-07-31 09:38:03  1 0  0 0  0 0
2 1  www.hokutoshobo.jp  /book/  2012-05-28 17:05:44 2024-08-30 08:47:51  1 0  0 0  0 0
3 1  www.hokutoshobo.jp  /news/  2012-05-30 16:50:17 2024-09-28 02:18:54  1 0  0 0  0 0

ここを => www.hokutoshobo.jp
phpMyAdminで、こういうふうに変更だったよね、
http://localhost:8888/hokuto-bs
どうだっただろうか？


ダメだ。

SHOW GRANTS FOR 'root'@'localhost';
を実行して、返ったきたのが以下

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, RELOAD, SHUTDOWN, PROCESS, FILE, REFERENCES, INDEX, ALTER, SHOW DATABASES, SUPER, CREATE TEMPORARY TABLES, LOCK TABLES, EXECUTE, REPLICATION SLAVE, REPLICATION CLIENT, CREATE VIEW, SHOW VIEW, CREATE ROUTINE, ALTER ROUTINE, CREATE USER, EVENT, TRIGGER, CREATE TABLESPACE, CREATE ROLE, DROP ROLE ON *.* TO `root`@`localhost` WITH GRANT OPTION
GRANT APPLICATION_PASSWORD_ADMIN,AUDIT_ABORT_EXEMPT,AUDIT_ADMIN,AUTHENTICATION_POLICY_ADMIN,BACKUP_ADMIN,BINLOG_ADMIN,BINLOG_ENCRYPTION_ADMIN,CLONE_ADMIN,CONNECTION_ADMIN,ENCRYPTION_KEY_ADMIN,FIREWALL_EXEMPT,FLUSH_OPTIMIZER_COSTS,FLUSH_STATUS,FLUSH_TABLES,FLUSH_USER_RESOURCES,GROUP_REPLICATION_ADMIN,GROUP_REPLICATION_STREAM,INNODB_REDO_LOG_ARCHIVE,INNODB_REDO_LOG_ENABLE,PASSWORDLESS_USER_ADMIN,PERSIST_RO_VARIABLES_ADMIN,REPLICATION_APPLIER,REPLICATION_SLAVE_ADMIN,RESOURCE_GROUP_ADMIN,RESOURCE_GROUP_USER,ROLE_ADMIN,SENSITIVE_VARIABLES_OBSERVER,SERVICE_CONNECTION_ADMIN,SESSION_VARIABLES_ADMIN,SET_USER_ID,SHOW_ROUTINE,SYSTEM_USER,SYSTEM_VARIABLES_ADMIN,TABLE_ENCRYPTION_ADMIN,TELEMETRY_LOG_ADMIN,XA_RECOVER_ADMIN ON *.* TO `root`@`localhost` WITH GRANT OPTION
GRANT PROXY ON ``@`` TO `root`@`localhost` WITH GRANT OPTION

これでサーバー再起動してアクセスしたがやはりダメだ。
http://localhost:8888/hokuto-bs/wp-admin/

データベース接続確立エラー
サイトが表示されない場合は、このサイトネットワークの所有者に管理してください。 If you are the owner of this network please check that your host’s database server is running properly and all tables are error free.

サイト localhost:8888/hokuto-bs が見つかりません。データベース hokuto-bs-db のテーブルで wp_blogs を検索しました。間違いありませんか ?

どうしましょうか ? Read the Debugging a WordPress Network article. Some of the suggestions there may help you figure out what went wrong. If you are still stuck with this message, then check that your database contains the following tables:

wp_users
wp_usermeta
wp_blogs
wp_blogmeta
wp_signups
wp_site
wp_sitemeta
wp_registration_log

こんなのが返ってくる。
助けてください。


/Applications/MAMP/logs/mysql_error.log
エラーログです。

2024-10-10T00:50:45.6NZ mysqld_safe Logging to '/Applications/MAMP/logs/mysql_error.log'.
2024-10-10T00:50:45.6NZ mysqld_safe Starting mysqld daemon with databases from /Applications/MAMP/db/mysql80
2024-10-10T00:50:46.140047Z 0 [System] [MY-010116] [Server] /Applications/MAMP/Library/bin/mysql80/bin/mysqld (mysqld 8.0.35) starting as process 8793
2024-10-10T00:50:46.141751Z 0 [Warning] [MY-010159] [Server] Setting lower_case_table_names=2 because file system for /Applications/MAMP/db/mysql80/ is case insensitive
2024-10-10T00:50:46.143705Z 1 [System] [MY-013576] [InnoDB] InnoDB initialization has started.
2024-10-10T00:50:46.199482Z 1 [System] [MY-013577] [InnoDB] InnoDB initialization has ended.
2024-10-10T00:50:46.271504Z 0 [Warning] [MY-010068] [Server] CA certificate ca.pem is self signed.
2024-10-10T00:50:46.271524Z 0 [System] [MY-013602] [Server] Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.
2024-10-10T00:50:46.277374Z 0 [System] [MY-011323] [Server] X Plugin ready for connections. Bind-address: '::' port: 33060, socket: /Applications/MAMP/tmp/mysql/mysqlx.sock
2024-10-10T00:50:46.277393Z 0 [System] [MY-010931] [Server] /Applications/MAMP/Library/bin/mysql80/bin/mysqld: ready for connections. Version: '8.0.35'  socket: '/Applications/MAMP/tmp/mysql/mysql.sock'  port: 8889  Source distribution.
2024-10-10T00:50:47.582116Z 8 [Warning] [MY-013360] [Server] Plugin mysql_native_password reported: ''mysql_native_password' is deprecated and will be removed in a future release. Please use caching_sha2_password instead'
2024-10-10T00:50:49.746403Z 9 [Warning] [MY-013360] [Server] Plugin mysql_native_password reported: ''mysql_native_password' is deprecated and will be removed in a future release. Please use caching_sha2_password instead'
2024-10-10T00:50:51.999662Z 10 [Warning] [MY-013360] [Server] Plugin mysql_native_password reported: ''mysql_native_password' is deprecated and will be removed in a future release. Please use caching_sha2_password instead'
以下同じ記述が続く

どうしたらいいですか？




blog_id site_id  domain  path  registered  last_updated  public  archived  mature  spam  deleted lang_id
1 1 localhost:8888 /  2012-05-28 15:39:41 2021-07-31 09:38:03  1 0  0 0  0 0
2 1  localhost:8888  /book/  2012-05-28 17:05:44 2024-08-30 08:47:51  1 0  0 0  0 0
3 1  localhost:8888  /news/  2012-05-30 16:50:17 2024-09-28 02:18:54  1 0  0 0  0 0

wp-blogsでの記述をlocalhostからlocalhost:8888に変更したら次のエラーが出た。

Fatal error: Array and string offset access syntax with curly braces is no longer supported in /Applications/MAMP/htdocs/hokuto-bs/wp-content/plugins/custom-field-template/custom-field-template.php on line 3249

これはwp-content/pluginsの名前を『plugins_とりあえず外す』というように変更してからアクセスしたらいいのか？

INSERT INTO wp_options (option_name, option_value, autoload) VALUES ('home', 'http://localhost:8888/hokuto-bs', 'yes');

UPDATE wp_options 
SET option_value = 'http://localhost:8888/hokuto-bs' 
WHERE option_name = 'home';


blog_id site_id  domain  path  registered  last_updated  public  archived  mature  spam  deleted lang_id
1 1  localhost:8888  /hokuto-bs/ 2012-05-28 15:39:41  2021-07-31 09:38:03 1  0 0  0 0  0
2 1  localhost:8888  /hokuto-bs/book/  2012-05-28 17:05:44 2024-08-30 08:47:51  1 0  0 0  0 0
3  1 localhost:8888 /hokuto-bs/news/ 2012-05-30 16:50:17  2024-09-28 02:18:54 1  0 0  0 0  0 

blog_id site_id  domain  path  registered  last_updated  public  archived  mature  spam  deleted lang_id
1 1  localhost:8888/hokuto-bs  / 2012-05-28 15:39:41  2021-07-31 09:38:03 1  0 0  0 0  0
2 1  localhost:8888/hokuto-bs  /book/  2012-05-28 17:05:44 2024-08-30 08:47:51  1 0  0 0  0 0
3  1 localhost:8888/hokuto-bs  /news/ 2012-05-30 16:50:17  2024-09-28 02:18:54 1  0 0  0 0  0 



現状の確認。

* ログインはできる。
* http://localhost:8888/hokuto-bs/wp-admin/ 表示できる。
* http://localhost:8888/hokuto-bs/ にアクセスすると、このサイトで重大なエラーが発生しましたとなる
* 以下、表示できない。
  Not Found
  The requested URL was not found on this server.
  となる。
  http://localhost:8888/hokuto-bs/book/wp-admin/
  http://localhost:8888/hokuto-bs/book/
  http://localhost:8888/hokuto-bs/news/wp-admin/
  http://localhost:8888/hokuto-bs/news/
* プラグインは全て外している状態。

どうやったら3つのWPを連携したものを表示できるようになるのか？


domain: localhost:8888
path: /hokuto-bs/
/hokuto-bs/book/
/hokuto-bs/news/

wp_site テーブル
domain: localhost:8888
path: /hokuto-bs/

wp_sitemeta テーブル
siteurl: http://localhost:8888/hokuto-bs/
home: これはなかった。


http://localhost:8888/hokuto-bs/wp-admin/network/
http://localhost:8888/hokuto-bs/wp-admin/network/sites.php
http://localhost:8888/hokuto-bs/wp-admin/network/users.php
http://localhost:8888/hokuto-bs/wp-admin/network/themes.php
http://localhost:8888/hokuto-bs/wp-admin/network/plugins.php
http://localhost:8888/hokuto-bs/wp-admin/network/settings.php

http://localhost:8888/hokuto-bs/wp-admin/my-sites.php


/%category%/%post_id%/


[Thu Oct 10 15:57:20.288399 2024] [mpm_event:notice] [pid 42347:tid 8654910016] AH00491: caught SIGTERM, shutting down
[Thu Oct 10 15:57:20.299831 2024] [:alert] [pid 42348:tid 8654910016] (4)Interrupted system call: FastCGI: read() from pipe failed (0)
[Thu Oct 10 15:57:20.300100 2024] [:alert] [pid 42348:tid 8654910016] (4)Interrupted system call: FastCGI: the PM is shutting down, Apache seems to have disappeared - bye
[Thu Oct 10 15:57:25.515638 2024] [:notice] [pid 43348:tid 8654910016] FastCGI: process manager initialized (pid 43348)
[Thu Oct 10 15:57:25.516387 2024] [mpm_event:notice] [pid 43343:tid 8654910016] AH00489: Apache/2.4.58 (Unix) OpenSSL/1.1.1u mod_fastcgi/mod_fastcgi-SNAP-0910052141 configured -- resuming normal operations
[Thu Oct 10 15:57:25.516540 2024] [core:notice] [pid 43343:tid 8654910016] AH00094: Command line: '/Applications/MAMP/Library/bin/httpd'


現在の状況

* この、http://localhost:8888/hokuto-bs/wp-admin/ => adminに入れる。
* この、http://localhost:8888/hokuto-bs/ => home（トップ）ページに行ける。
* home（トップ）ページのCSSが全く効いていない。
* home（トップ）ページ内のリンクをクリックする。
例えば、本来であれば、
http://localhost:8888/hokuto-bs/book/のはずが、飛んだ先は、http://localhost:8888/book/
http://localhost:8888/hokuto-bs/news/のはずが、飛んだ先は、http://localhost:8888/news/
hokuto-bsがない。

どうしたら正しい住所に飛べるのか？
それができたらCSSも聞くはずだが？　教えてくれ。



トップページのサーバーでphpからHTMLに変換された表示に使われているものの住所の状態を抜き出した。

住所がまともな状態のもの

<!-- saved from url=(0032)http://localhost:8888/hokuto-bs/ -->
<link rel="canonical" href="http://localhost:8888/hokuto-bs/">
<link rel="https://api.w.org/" href="http://localhost:8888/hokuto-bs/wp-json/">
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost:8888/hokuto-bs/xmlrpc.php?rsd">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost:8888/hokuto-bs/wp-includes/wlwmanifest.xml"> 
<form method="get" id="searchform" action="http://localhost:8888/hokuto-bs/">

住所にhokuto-bs/が抜けてしまっているもの

<link rel="contents" href="http://localhost:8888/" title="ホーム">
<p class="logo"><a href="http://localhost:8888/"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/logo.png" alt="京都 下鴨 洛北の出版社「自費出版の北斗書房」" class="colorbox-manual"></a></p>
<p class="btContact"><a href="http://localhost:8888/contact/">お問い合わせ</a></p>
<li class="menuTop"><a href="http://localhost:8888/">ホーム</a></li>
<li class="menu01"><a href="http://localhost:8888/feature/">当社の特徴</a></li>
<li class="menu02"><a href="http://localhost:8888/price/">料金プラン</a></li>
<li class="menu08"><a href="http://localhost:8888/process/">自費出版制作の流れ</a></li>
<li class="menu04"><a href="http://localhost:8888/knowledge/">豆知識</a></li>
<li class="menu05"><a href="http://localhost:8888/voice/">お客様の声</a></li>
<li class="menu06"><a href="http://localhost:8888/faq/">Ｑ＆Ａ</a></li>
<li class="menu07"><a href="http://localhost:8888/access/">アクセス</a></li>
<a href="http://localhost:8888/purchase/" style="float:right;"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/bt-purchase.png" alt="自費出版のご購入方法" class="colorbox-manual"></a>
<p><a href="http://localhost:8888/book/">書籍一覧はこちら</a></p>
<li class="btHistory"><a href="http://localhost:8888/news/">新着一覧</a></li>

住所に不要な『/』がついてしまっているもの

<a href="http://localhost:8888/hokuto-bs/book//book-author/1374/"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/978-4-89467-499-8.jpg" alt="室　達郎 句集　忘筌" class="colorbox-manual"></a>
<h4><a href="http://localhost:8888/hokuto-bs/book//book-author/1374/">
<a href="http://localhost:8888/hokuto-bs/book//genre/1371/"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/978-4-89467-483-7.jpg" alt="追憶の今出川キャンパス ―良心・自由・自治・自立―" class="colorbox-manual"></a>
<h4><a href="http://localhost:8888/hokuto-bs/book//genre/1371/">
<a href="http://localhost:8888/hokuto-bs/book//book-author/1367/"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/978-4-89467-505-6.jpg" alt="有機農業に夢を託して －退職後初めての農業で知ったこと・考えたこと－" class="colorbox-manual"></a>
<h4><a href="http://localhost:8888/hokuto-bs/book//book-author/1367/">
<a href="http://localhost:8888/hokuto-bs/book//book-author/1348/"><img src="./京都 下鴨 洛北の出版社「自費出版の北斗書房」_files/978-4-89467-493-6._0015jpg.jpg" alt="『阿弥陀経』の構造の研究" class="colorbox-manual"></a>
<h4><a href="http://localhost:8888/hokuto-bs/book//book-author/1348/">

この状態から推測できるものは何か？
どこを直したらいいかわかりますか？



UPDATE wp_posts SET post_content = REPLACE(post_content, 'http://localhost:8888/', 'http://localhost:8888/hokuto-bs/');
UPDATE wp_postmeta SET meta_value = REPLACE(meta_value, 'http://localhost:8888/', 'http://localhost:8888/hokuto-bs/');

これはDBeaverを使ってやりました。

問題を発見しています。

wp-postsのguid
wp-postmetaのmeta_value
wp-optionsのoption_value

それぞれ値に移行する前のサイトの住所が入っています。
http://www.hokutoshobo.jp

これを置き換える必要はありますねよ？
置き換える場合のsqlを教えてください。

UPDATE wp_options 
SET option_value = REPLACE(option_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs/')
WHERE option_value LIKE 'http://www.hokutoshobo.jp%';

UPDATE wp_options SET option_value = REPLACE(option_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs/') WHERE option_value LIKE 'http://www.hokutoshobo.jp%';


---
UPDATE wp_2_posts SET guid = REPLACE(guid, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs');
---
UPDATE wp_2_postmeta SET meta_value = REPLACE(meta_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs');
---
UPDATE wp_2_options SET option_value = REPLACE(option_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs') WHERE option_value LIKE 'http://www.hokutoshobo.jp%';
---
UPDATE wp_3_posts SET guid = REPLACE(guid, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs');
---
UPDATE wp_3_postmeta SET meta_value = REPLACE(meta_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs');
---
UPDATE wp_3_options SET option_value = REPLACE(option_value, 'http://www.hokutoshobo.jp', 'http://localhost:8888/hokuto-bs') WHERE option_value LIKE 'http://www.hokutoshobo.jp%';


レンタルサーバー上で3つのWPを連携するサイトを運営していたようだ。
それをリニューアルしないといけない。
サイトとDBをローカルに落として、現状表示されている状態を再現するべくやってきた。

現状は、
http://localhost:8888/hokuto-bs/wp-admin/
http://localhost:8888/hokuto-bs/
とその配下にあるページはすべてCSSを噛ませて正常に表示できるようになった。

問題は、
サイトネットワーク管理にいこうとすると、hokuto-bsが抜けてしまう現象が起こることが一つと、
http://localhost:8888/wp-admin/network/

ダッシュボード上の以下のようなリンクをクリックすると
http://localhost:8888/hokuto-bs/
にリダイレクトされてしまう。

<p class="my-sites-actions">
<a href="http://localhost:8888/hokuto-bs">表示</a> 
| 
<a href="http://localhost:8888/hokuto-bs/wp-admin/">ダッシュボード</a>
</p>

<p class="my-sites-actions">
<a href="http://localhost:8888/hokuto-bs">表示</a>
 | 
<a href="http://localhost:8888/hokuto-bs/wp-admin/">ダッシュボード</a>
</p>

<p class="my-sites-actions">
<a href="http://localhost:8888/hokuto-bs/news">表示</a>
| 
<a href="http://localhost:8888/hokuto-bs/news/wp-admin/">ダッシュボード</a>
</p>

ここを解決できたらレンタルサーバーからローカルに落とす作業は一段落する。
頼む解決方法を教えてくれ。


以下のリンクについて、

<li>
  <h3>京都 下鴨 洛北の出版社「自費出版の北斗書房」</h3>
  <p class="my-sites-actions">
    <a href="http://localhost:8888/hokuto-bs">表示</a> | 
    <a href="http://localhost:8888/hokuto-bs/wp-admin/">ダッシュボード</a>
  </p>
</li>

<li>
  <h3>書籍一覧｜京都 下鴨 洛北の出版社「自費出版の北斗書房」</h3>
  <p class="my-sites-actions">
    <a href="http://localhost:8888/hokuto-bs/book">表示</a> | 
    <a href="http://localhost:8888/hokuto-bs/book/wp-admin/">ダッシュボード</a>
  </p>
</li>

<li>
  <h3>ブログ｜京都 下鴨 洛北の出版社「自費出版の北斗書房」</h3>
  <p class="my-sites-actions">
    <a href="http://localhost:8888/hokuto-bs/news">表示</a> | 
    <a href="http://localhost:8888/hokuto-bs/news/wp-admin/">ダッシュボード</a>
  </p>
</li>

これについては問題がない。
<a href="http://localhost:8888/hokuto-bs">表示</a> | 
<a href="http://localhost:8888/hokuto-bs/wp-admin/">ダッシュボード</a>

これについて、
<a href="http://localhost:8888/hokuto-bs/book">表示</a> | 
<a href="http://localhost:8888/hokuto-bs/book/wp-admin/">ダッシュボード</a>
<a href="http://localhost:8888/hokuto-bs/news">表示</a> | 
<a href="http://localhost:8888/hokuto-bs/news/wp-admin/">ダッシュボード</a>

これらについては問題なくリンク先に飛んで表示できる。
<a href="http://localhost:8888/hokuto-bs/book">表示</a> | 
<a href="http://localhost:8888/hokuto-bs/news">表示</a> | 

問題がこれらです。
<a href="http://localhost:8888/hokuto-bs/book/wp-admin/">ダッシュボード</a>
<a href="http://localhost:8888/hokuto-bs/news/wp-admin/">ダッシュボード</a>

WEB API(ブラウザ)に怒られた。

このページは動作していません
localhost でリダイレクトが繰り返し行われました。
Cookie を削除してみてください.
ERR_TOO_MANY_REDIRECTS

リダイレクトの記述がおかしいはず。
直してほしい。


信じられないから保管する。

# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /hokuto-bs/
RewriteRule ^index\.php$ - [L]

# Add trailing slash to /wp-admin
RewriteRule ^wp-admin$ wp-admin/ [R=301,L]

RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]
RewriteRule ^(wp-(content|admin|includes).*) /hokuto-bs/$1 [L]
RewriteRule ^(.*\.php)$ /hokuto-bs/$1 [L]
RewriteRule . index.php [L]
</IfModule>
# END WordPress


# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /hokuto-bs/

# Only apply rules to actual files and directories
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]
# Route everything else to index.php
RewriteRule . index.php [L]
</IfModule>
# END WordPress
~                      


# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress


大きなエラーです。
これを修正しないと投稿記事を書けません。
やばいです。

以下のリンクを叩くと、
http://localhost:8888/hokuto-bs/book/wp-admin/
http://localhost:8888/hokuto-bs/news/wp-admin/

```
このページは動作していません
localhost でリダイレクトが繰り返し行われました。
Cookie を削除してみてください.
ERR_TOO_MANY_REDIRECTS
```
のメッセージが真っ黒な画面に表示がされます。

検索窓は
それぞれ、
http://localhost:8888/hokuto-bs/book/wp-admin/
にアクセスしたら
http://localhost:8888/hokuto-bs/book/wp-admin/
にいく。

http://localhost:8888/hokuto-bs/news/wp-admin/
にアクセスしたら
http://localhost:8888/hokuto-bs/news/wp-admin/
にいくのですね！！！！
ママです。

ここにアクセスできないと、ブログ記事を追記していけません。
このサイトの肝です。
修正できないと絶対にダメです。
対策を教えてください。



# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /hokuto-bs/
# Only apply rules to actual files and directories
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]
# Route everything else to index.php
RewriteRule . index.php [L]
</IfModule>
# END WordPress



こんにちは、髙廣です。
こんな時間にすいません、取り急ぎ質問をさせていただきます。
お返事は来週以降で全然結構です。。。すいません。。。

弊社の北斗書房という組織がWPでサイトを持っております。
12年前に作られたサイトでして『サイトネットワーク管理』という機能を使い、1つの本管になるサイトと、2つの投稿記事を載せるサイトで構成されています。

ずっーと更新作業をしておりません。
DB、PHP、WPのバージョンは当時のままのようです。

リニューアルにあたり、
* ローカルに落として動くようにする。
* DB、PHP、WPのバージョンを上げる。
* リニューアル作業

という流れで考えております。

現在、ローカルに落として動くようにしている最中です。
今週から始めまして、なんとか3つのサイトとも動くようにはなりました。

ただ、大変大きい問題が残っております。
それは、2つの投稿サイトのダッシュボード（wp-admin）にアクセスするとリダイレクトがかかってしまいます。

検索窓は『http://localhost:8888/hokuto-bs/book/wp-admin/』や
『http://localhost:8888/hokuto-bs/news/wp-admin/』を入力したままで、

画面には、

```
このページは動作していません
localhost でリダイレクトが繰り返し行われました。
Cookie を削除してみてください.
ERR_TOO_MANY_REDIRECTS
```

こんな状況です。

.htaccessの問題だと考え、ChatGPTに教えられた設定は、

```
RewriteEngine On
RewriteBase /hokuto-bs/
RewriteRule ^index\.php$ - [L]

# Avoid redirect loop for /wp-admin
RewriteCond %{REQUEST_URI} !^/hokuto-bs/(book|news)/wp-admin/
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# WordPress-specific rewrites
RewriteRule ^(wp-(content|admin|includes).*) /hokuto-bs/$1 [L]
RewriteRule ^(.*\.php)$ /hokuto-bs/$1 [L]
RewriteRule . index.php [L]
```

wp-config.phpへマルチサイトの設定は、

```
define('WP_ALLOW_MULTISITE', true);
define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'localhost:8888'); // ここにポート番号を追加
define('PATH_CURRENT_SITE', '/hokuto-bs/'); // サブディレクトリが正しいか確認
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);
```

どうしてもブログの2つのダッシュボードにアクセスできません。
何か解決のヒントはないかと思い質問をさせていただきました。

現状、動いているサイトもURLもお伝えしたします。
http://www.hokutoshobo.jp/

お忙しいところ申し訳ありません。
よろしくお願いいたします。
